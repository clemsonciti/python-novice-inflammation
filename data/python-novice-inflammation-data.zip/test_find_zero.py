from count import count_zero_rows

assert(count_zero_rows('small-01.csv') == 2)
assert(count_zero_rows('small-02.csv') == 0)
assert(count_zero_rows('small-03.csv') == 1)
assert(count_zero_rows('small-04.csv') == 3)
assert(count_zero_rows('small-05.csv') == 2)
